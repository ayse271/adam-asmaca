
const kelimeler = [
    {kelime: "kıvırcık", tur: "Sebze"},
    {kelime: "ayşe", tur: "İsim"},
    {kelime: "maraş", tur: "Şehir"},
    {kelime: "türkoğlu", tur: "İlçe"},
    {kelime: "domates", tur: "Sebze"},
    {kelime: "salatalık", tur: "Sebze"},
    {kelime: "biber", tur: "Sebze"},
    {kelime: "tarla", tur: "Mekan"},
    {kelime: "irem", tur: "İsim"},
    {kelime: "gülsü", tur: "İsim"},
    {kelime: "uçurtma", tur: "Nesne"},
    {kelime: "zeytinyağı", tur: "Yiyecek"},
    {kelime: "yıldız", tur: "Doğa"},
    {kelime: "bilgisayar", tur: "Teknoloji"},
    {kelime: "gökkuşağı", tur: "Doğa"},
    {kelime: "kelebek", tur: "Hayvan"},
    {kelime: "çiçek", tur: "Doğa"},
    {kelime: "masa", tur: "Nesne"},
    {kelime: "okul", tur: "Mekan"},
    {kelime: "balık", tur: "Hayvan"},
    {kelime: "araba", tur: "Araç"},
    {kelime: "kalem", tur: "Nesne"},
    {kelime: "pencere", tur: "Nesne"}
];

let skor = 0;
let oyunDurumu = {};

function oyunBaslat() {
    let secim = kelimeler[Math.floor(Math.random() * kelimeler.length)];
    oyunDurumu.kelime = secim.kelime;
    oyunDurumu.tur = secim.tur;
    oyunDurumu.gorunen = Array(oyunDurumu.kelime.length).fill("_");
    oyunDurumu.yanlisHarfler = [];
    oyunDurumu.kalanHak = 10;
    document.getElementById("kelimeTuru").textContent = "Kelime Türü: " + oyunDurumu.tur;
    document.getElementById("kelime").textContent = oyunDurumu.gorunen.join(" ");
    document.getElementById("yanlisHarfler").textContent = "";
    document.getElementById("kalanHak").textContent = oyunDurumu.kalanHak;
    document.getElementById("sonuc").textContent = "";
    document.getElementById("adamResmi").src = "img0.png";
}

function tahminEt() {
    const input = document.getElementById("harfInput");
    const harf = input.value.toLowerCase();
    input.value = "";

    if (!harf || harf.length !== 1 || !harf.match(/[a-zçğıöşü]/i)) return;

    let bulundu = false;
    for (let i = 0; i < oyunDurumu.kelime.length; i++) {
        if (oyunDurumu.kelime[i] === harf) {
            oyunDurumu.gorunen[i] = harf;
            bulundu = true;
        }
    }

    if (!bulundu && !oyunDurumu.yanlisHarfler.includes(harf)) {
        oyunDurumu.yanlisHarfler.push(harf);
        oyunDurumu.kalanHak--;
        const kalan = 10 - oyunDurumu.kalanHak;
        document.getElementById("adamResmi").src = "img" + Math.min(kalan, 6) + ".png";
    }

    document.getElementById("kelime").textContent = oyunDurumu.gorunen.join(" ");
    document.getElementById("yanlisHarfler").textContent = oyunDurumu.yanlisHarfler.join(", ");
    document.getElementById("kalanHak").textContent = oyunDurumu.kalanHak;

    if (oyunDurumu.gorunen.join("") === oyunDurumu.kelime) {
        skor += 10;
        document.getElementById("sonuc").textContent = "Tebrikler, kelimeyi buldunuz!";
        document.getElementById("skor").textContent = skor;
    } else if (oyunDurumu.kalanHak === 0) {
        document.getElementById("sonuc").textContent = "Oyun bitti! Doğru kelime: " + oyunDurumu.kelime;
    }
}

function yenidenBaslat() {
    oyunBaslat();
}

oyunBaslat();
